import music1 from "./stay.mp3";
import music2 from "./deserve-you.mp3";
import music3 from "./yummy.mp3";

const songs = {
	music1,
	music2,
	music3,
};

export default songs;
